import paramiko
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect('192.168.100.127',username='durga',password='password')
stdin,stdout,stderr=\
ssh.exec_command("uptime")
type(stdin)
#print(stdin)
#print("\n stdout is:\n" + stdout.read() + "\n stderr is:\n" + stderr.read())
print(stdout.readlines())
