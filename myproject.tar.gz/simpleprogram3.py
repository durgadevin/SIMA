import psutil
import sys
import datetime
import json

from flask import Flask
print ('time and date', datetime.datetime.strftime(datetime.datetime.now(),'%Y-%m-%d %H:%M:%S'))
app = Flask(__name__)
@app.route('/')
#def index():
#        pinfo= proc.as_dict(attrs = [
#        {'pid'},
#      	]
#        	return 'jsonify(result=pinfo)'

#if __name__ == '__main__':
#    app.run( )
def cpu():
	pinfo=psutil.cpu_times()
#	pinfo=psutil.users()
#	pinfo = proc.as_dict(attrs=['pid', 'name'])
#	print(json.dumps(pinfo))
#	return json.dumps({
#	"name": "santhosh", "terminal": "tty7", "host": "localhost", "started": 1470805294.0})	
#	return json.loads(pinfo)
	return json.dumps(pinfo)

#cpu()
if __name__== '__main__':
	app.run()	


