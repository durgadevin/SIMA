from flask import Flask,jsonify

app= Flask(__name__)
#@app.route('/')
@app.route('/', methods=['GET','POST'])
def index():
	list=[
	{'param':'foo', 'val':2},
	{'param':'bar', 'val':3},
      ]
	return jsonify(result=list)
#	myproj = json.loads(jsonify)
#	print(myproj)

if __name__ == '__main__':
    app.run( )

