import paramiko
 
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
try:
        ssh.connect('192.168.100.127', username='durga', password='password')
except paramiko.SSHException:
        print("Connection Failed")
        quit()
 
stdin,stdout,stderr = ssh.exec_command("ls") 
#for line in stdout.readlines():
#print(line.strip())
print(stdout.readlines())
ssh.close()
