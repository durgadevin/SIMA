import psutil

PROCNAME = "firefox"

for proc in psutil.iter():
    if proc.name() == PROCNAME:
        print(proc)
