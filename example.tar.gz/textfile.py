impor sys
import os.path
import psutil

print('process map at:')

for proc in psutil.process_iter():
    try:
        pinfo = proc.as_dict(attrs=['pid', 'name', 'exe', 'username', 'memory'])
    except psutil.NoSuchProcess:
        pass
    else:
        print(pinfo)t sys
import os.path

orig = sys.stdout
with open("txtfile.txt", "r") as f:
    sys.stdout = f
    
