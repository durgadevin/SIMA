import psutil
import datetime
import sys
sys.stdout=open("test.txt","w")
print('process map at:',datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d %H:%M:%S'))


for proc in psutil.process_iter():
    try:
        pinfo = proc.as_dict(attrs=['pid','name'])
    except psutil.NoSuchProcess:
        pass
    else:
        print(pinfo)
sys.stdout.close()
