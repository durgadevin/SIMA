import psutil
p = psutil.Process()
p.as_dict(attrs=['pid', 'name', 'username'])
