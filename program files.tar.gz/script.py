import sys
import os.path
import psutil

print('process map at:')

for proc in psutil.process_iter():
    try:
        pinfo = proc.as_dict(attrs=['pid', 'name', 'exe', 'username', 'memory'])
    except psutil.NoSuchProcess:
        pass
    else:
        print(pinfo)
