import json
import stripe
import smtplib
import reques

from flask import Flask, request, jsonify

application = Flask(__name__)

@application.route('/run_post')
def run_post():
    url = 'http://xxx.pythonanywhere.com/stripetest'
    data = {'stripeAmount': '199', 'stripeCurrency': 'USD', 'stripeToken': '122', 'stripeDescription': 'Test post'}
    headers = {'Content-Type' : 'application/json'}

    r = requests.post(url, data, headers=headers)

    #return json.dumps(r.json(), indent=4)
    return r.text

@application.route('/stripetest', methods=["POST"])
def stripeTest():

    if request.method == "POST":

        json_dict = json.loads(request.body.raw)

        stripeAmount = json_dict['stripeAmount']
        stripeCurrency = json_dict['stripeCurrency']
        stripeToken = json_dict['stripeToken']
        stripeDescription = json_dict['stripeDescription']

        data = "{'stripeAmountRet': " +  stripeAmount + ", 'stripeCurrencyRet': " + stripeCurrency + ", 'stripeTokenRet': " + stripeToken + ", 'stripeDescriptionRet': " + stripeDescription + "}"

        return jsonify(data)
    else:

        return """<html><body>
        Something went horribly wrong
        </body></html>"""
if __name__ == "__main__":
    application.run()

